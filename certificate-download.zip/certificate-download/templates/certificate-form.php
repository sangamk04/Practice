<div class="certificate-download-container">
    <header>
        <div class="logo">
            <i class="fas fa-certificate"></i>
        </div>
        <h1>IGSFI Certificate Download Center</h1>
        <p class="subtitle">Enter your certificate number to verify and download your certificate</p>
    </header>
    
    <div class="main-content">
        <div class="input-section">
            <h2 class="section-title">Enter Certificate Details</h2>
            
            <div class="input-group">
                <label for="certNumber">Certificate Number</label>
                <div class="input-container">
                    <i class="fas input-icon"></i>
                    <input 
                        type="text" 
                        id="certNumber" 
                        placeholder="Enter certificate number"
                        autocomplete="off"
                    >
                </div>
            </div>
            
            <div class="message error-message" id="errorMessage">
                <i class="fas fa-exclamation-circle"></i>
                <span id="errorText">Certificate not found. Please check your certificate number.</span>
            </div>
            
            <div class="message success-message" id="successMessage">
                <i class="fas fa-check-circle"></i>
                <span>Certificate verified! Preview available below.</span>
            </div>
            
            <button class="btn btn-primary" id="verifyBtn">
                <i class="fas fa-check"></i> Verify Certificate
            </button>
            <a href="https://igsfindia.com/" class="btn btn-secondary" id="homeBtn">
    <i class="fas fa-home"></i> Go to Home Page
</a>

            
            <div class="info-box">
                <p><strong>How to use this system:</strong></p>
                <ul>
                    <li>Enter your certificate number exactly as provided</li>
                    <li>Click "Verify Certificate" to check validity</li>
                    <li>Preview will appear for valid certificates</li>
                    <li>Click "Download Certificate" to save your file</li>
                </ul>
            </div>
        </div>
        
        <div class="preview-section">
            <h2 class="section-title">Certificate Preview</h2>
            
            <div class="preview-container" id="previewContainer">
                <div class="preview-content" id="defaultPreview">
                    <div class="preview-icon">
                        <i class="fas fa-file-certificate"></i>
                    </div>
                    <p class="preview-text">Certificate preview will appear here</p>
                </div>
                <img src="" class="certificate-preview" id="certificatePreview" alt="Certificate Preview">
            </div>
            
            <div class="file-info" id="fileInfo"></div>
            
            <button class="btn btn-download" id="downloadBtn">
                <i class="fas fa-download"></i> Download Certificate
            </button>
        </div>
    </div>
    
    <footer>
        <p>© <?php echo date('Y'); ?> | All rights reserved</p>
    </footer>
</div>