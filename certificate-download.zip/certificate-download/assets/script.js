jQuery(document).ready(function($) {
    const certNumberInput = $('#certNumber');
    const verifyBtn = $('#verifyBtn');
    const homeBtn = $('#homeBtn');
    const downloadBtn = $('#downloadBtn');
    const errorMessage = $('#errorMessage');
    const successMessage = $('#successMessage');
    const previewContainer = $('#previewContainer');
    const defaultPreview = $('#defaultPreview');
    const certificatePreview = $('#certificatePreview');
    const errorText = $('#errorText');
    const fileInfo = $('#fileInfo');
    const actions = $('.cdc-actions');
    
    // Verify certificate
    verifyBtn.on('click', function() {
        const certNumber = certNumberInput.val().trim().toUpperCase();
        
        // Reset messages and preview
        errorMessage.hide();
        successMessage.hide();
        downloadBtn.hide();
        certificatePreview.hide();
        fileInfo.text('');
        defaultPreview.show();
        defaultPreview.html(`
            <div class="preview-icon">
                <i class="fas fa-file-certificate"></i>
            </div>
            <p class="preview-text">Certificate preview will appear here</p>
        `);
        actions.hide();
        
        if (!certNumber) {
            showError('Please enter a certificate number');
            return;
        }
        
        // Show loading state
        verifyBtn.html('<i class="fas fa-spinner fa-spin"></i> Verifying...').prop('disabled', true);
        
        // Check certificate existence via AJAX
        $.ajax({
            url: cdc_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'cdc_verify_certificate',
                cert_number: certNumber,
                nonce: cdc_ajax.nonce
            },
            success: function(response) {
                verifyBtn.html('<i class="fas fa-search"></i> Verify').prop('disabled', false);
                
                if (response.success) {
                    // Show success message
                    successMessage.show();
                    
                    if (response.data.extension === 'png' || response.data.extension === 'jpg' || response.data.extension === 'jpeg') {
                        // For images, use our secure preview handler
                        certificatePreview.attr('src', cdc_ajax.ajax_url + '?action=cdc_serve_preview&cert_number=' + certNumber);
                        certificatePreview.attr('alt', 'Certificate ' + certNumber);
                        certificatePreview.show();
                        defaultPreview.hide();
                        fileInfo.text('File Type: ' + response.data.extension.toUpperCase());
                    } else {
                        // For PDF, show a placeholder
                        defaultPreview.html(`
                            <div class="preview-icon">
                                <i class="fas fa-file-pdf"></i>
                            </div>
                            <p class="preview-text">${certNumber}.pdf</p>
                            <p><small>Preview not available for PDF files</small></p>
                        `);
                        fileInfo.text('File Type: PDF');
                    }
                    
                    // Show download button
                    downloadBtn.show();
                    actions.show();
                    // Set data attribute for download
                    downloadBtn.data('certNumber', certNumber);
                    downloadBtn.data('extension', response.data.extension);
                } else {
                    showError('Certificate not found. Please check your certificate number.');
                }
            },
            error: function() {
                verifyBtn.html('<i class="fas fa-search"></i> Verify').prop('disabled', false);
                showError('Failed to verify certificate. Please try again.');
            }
        });
    });
    
    // Download certificate
    downloadBtn.on('click', function() {
        const certNumber = downloadBtn.data('certNumber');
        const extension = downloadBtn.data('extension');
        
        if (certNumber && extension) {
            // Create a form and submit it to trigger download
            const form = $('<form>', {
                method: 'POST',
                action: cdc_ajax.ajax_url,
                style: 'display: none;'
            });
            
            $('<input>').attr({
                type: 'hidden',
                name: 'action',
                value: 'cdc_download_certificate'
            }).appendTo(form);
            
            $('<input>').attr({
                type: 'hidden',
                name: 'cert_number',
                value: certNumber
            }).appendTo(form);
            
            $('body').append(form);
            form.submit();
        }
    });
    
    // Home button functionality
    homeBtn.on('click', function() {
        // Reset form
        certNumberInput.val('');
        errorMessage.hide();
        successMessage.hide();
        downloadBtn.hide();
        certificatePreview.hide();
        fileInfo.text('');
        defaultPreview.show();
        defaultPreview.html(`
            <div class="preview-icon">
                <i class="fas fa-file-certificate"></i>
            </div>
            <p class="preview-text">Certificate preview will appear here</p>
        `);
        actions.hide();
        
        if (downloadBtn.data('certNumber')) {
            downloadBtn.removeData('certNumber');
            downloadBtn.removeData('extension');
        }
    });
    
    // Show error message
    function showError(message) {
        errorText.text(message);
        errorMessage.show();
        
        // Add shake animation
        errorMessage.css('animation', 'shake 0.5s');
        setTimeout(() => {
            errorMessage.css('animation', '');
        }, 500);
    }
    
    // Add keypress event for Enter key
    certNumberInput.on('keypress', function(e) {
        if (e.which === 13) {
            verifyBtn.click();
        }
    });
});