<?php
/**
 * Plugin Name: Certificate Download Center
 * Description: Allows users to download certificates by entering certificate numbers
 * Version: 1.2
 * Author: sangam kumar singh 
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('CDC_PLUGIN_URL', plugin_dir_url(__FILE__));
define('CDC_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('CDC_CERTIFICATE_DIR', WP_CONTENT_DIR . '/uploads/certificates/');

// Create necessary directories on activation
register_activation_hook(__FILE__, 'cdc_activate_plugin');
function cdc_activate_plugin() {
    if (!file_exists(CDC_CERTIFICATE_DIR)) {
        wp_mkdir_p(CDC_CERTIFICATE_DIR);
    }
    
    // Add .htaccess to prevent direct access to certificates
    $htaccess_content = "Options -Indexes\nDeny from all";
    file_put_contents(CDC_CERTIFICATE_DIR . '.htaccess', $htaccess_content);
}

// Enqueue scripts and styles
add_action('wp_enqueue_scripts', 'cdc_enqueue_scripts');
function cdc_enqueue_scripts() {
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css');
    wp_enqueue_style('cdc-style', CDC_PLUGIN_URL . 'assets/style.css');
    
    wp_enqueue_script('cdc-script', CDC_PLUGIN_URL . 'assets/script.js', array('jquery'), null, true);
    
    $upload_dir = wp_upload_dir();
    wp_localize_script('cdc-script', 'cdc_ajax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('cdc_nonce'),
        'home_url' => home_url()
    ));
}

// Add admin menu for certificate management
add_action('admin_menu', 'cdc_admin_menu');
function cdc_admin_menu() {
    add_menu_page(
        'Certificate Management',
        'Certificates',
        'manage_options',
        'certificate-management',
        'cdc_admin_page',
        'dashicons-awards',
        30
    );
    
    // Add submenu items
    add_submenu_page(
        'certificate-management',
        'Upload New Certificate',
        'Upload New',
        'manage_options',
        'certificate-upload',
        'cdc_upload_page'
    );
    
    add_submenu_page(
        'certificate-management',
        'View Certificates',
        'View All',
        'manage_options',
        'certificate-view',
        'cdc_view_page'
    );
}

// Upload page
function cdc_upload_page() {
    ?>
    <div class="wrap">
        <h1>Upload New Certificate</h1>
        
        <div class="card">
            <form id="cdc-upload-form" method="post" enctype="multipart/form-data">
                <table class="form-table">
                    <tr>
                        <th><label for="certificate_number">Certificate Number</label></th>
                        <td>
                            <input type="text" name="certificate_number" id="certificate_number" required>
                            <p class="description">This will be used as the filename (without extension)</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="certificate_file">Certificate File</label></th>
                        <td>
                            <input type="file" name="certificate_file" id="certificate_file" accept=".pdf,.jpg,.jpeg,.png" required>
                            <p class="description">Allowed formats: PDF, JPG, JPEG, PNG</p>
                        </td>
                    </tr>
                </table>
                <?php wp_nonce_field('cdc_upload_nonce', 'cdc_nonce_field'); ?>
                <?php submit_button('Upload Certificate'); ?>
            </form>
            <div id="cdc-upload-message"></div>
        </div>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        $('#cdc-upload-form').on('submit', function(e) {
            e.preventDefault();
            
            var formData = new FormData(this);
            formData.append('action', 'cdc_handle_upload');
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    $('#cdc-upload-message').html(response);
                    if (response.success) {
                        $('#cdc-upload-form')[0].reset();
                    }
                }
            });
        });
    });
    </script>
    <?php
}

// View page
function cdc_view_page() {
    ?>
    <div class="wrap">
        <h1>Existing Certificates</h1>
        <div id="cdc-certificate-list">
            <?php cdc_list_certificates(); ?>
        </div>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        // Delete certificate
        $(document).on('click', '.cdc-delete-certificate', function(e) {
            e.preventDefault();
            var button = $(this);
            var filename = button.data('filename');
            
            if (confirm('Are you sure you want to delete this certificate?')) {
                $.post(ajaxurl, {
                    action: 'cdc_delete_certificate',
                    filename: filename,
                    nonce: '<?php echo wp_create_nonce('cdc_nonce'); ?>'
                }, function(response) {
                    if (response.success) {
                        button.closest('tr').fadeOut();
                    } else {
                        alert('Failed to delete certificate');
                    }
                });
            }
        });
    });
    </script>
    <?php
}

// Admin page content
function cdc_admin_page() {
    // Redirect to upload page as default
    echo '<script>window.location.href="' . admin_url('admin.php?page=certificate-upload') . '";</script>';
}

// Handle certificate upload via AJAX
add_action('wp_ajax_cdc_handle_upload', 'cdc_handle_upload');
function cdc_handle_upload() {
    // Verify nonce
    if (!wp_verify_nonce($_POST['cdc_nonce_field'], 'cdc_upload_nonce')) {
        wp_die('Security check failed');
    }
    
    // Check user capabilities
    if (!current_user_can('manage_options')) {
        wp_die('Insufficient permissions');
    }
    
    $certificate_number = sanitize_file_name($_POST['certificate_number']);
    $file = $_FILES['certificate_file'];
    
    // Validate file
    $allowed_types = array('pdf', 'jpg', 'jpeg', 'png');
    $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (!in_array($file_ext, $allowed_types)) {
        echo '<div class="error"><p>Invalid file type. Only PDF, JPG, JPEG, and PNG files are allowed.</p></div>';
        wp_die();
    }
    
    // Generate filename
    $filename = $certificate_number . '.' . $file_ext;
    $destination = CDC_CERTIFICATE_DIR . $filename;
    
    // Check if file already exists
    if (file_exists($destination)) {
        echo '<div class="error"><p>A certificate with this number already exists.</p></div>';
        wp_die();
    }
    
    // Move uploaded file
    if (move_uploaded_file($file['tmp_name'], $destination)) {
        echo '<div class="updated"><p>Certificate uploaded successfully!</p></div>';
    } else {
        echo '<div class="error"><p>Failed to upload certificate. Please try again.</p></div>';
    }
    
    wp_die();
}

// List existing certificates
function cdc_list_certificates() {
    $files = glob(CDC_CERTIFICATE_DIR . '*.*');
    
    if (empty($files)) {
        echo '<p>No certificates found.</p>';
        return;
    }
    
    echo '<table class="wp-list-table widefat fixed striped">';
    echo '<thead><tr><th>Filename</th><th>Type</th><th>Size</th><th>Actions</th></tr></thead>';
    echo '<tbody>';
    
    foreach ($files as $file) {
        $filename = basename($file);
        $filetype = wp_check_filetype($file);
        $filesize = size_format(filesize($file));
        
        echo '<tr>';
        echo '<td>' . esc_html($filename) . '</td>';
        echo '<td>' . esc_html(strtoupper($filetype['ext'])) . '</td>';
        echo '<td>' . esc_html($filesize) . '</td>';
        echo '<td><a href="#" class="button cdc-delete-certificate" data-filename="' . esc_attr($filename) . '">Delete</a></td>';
        echo '</tr>';
    }
    
    echo '</tbody></table>';
}

// Handle certificate deletion
add_action('wp_ajax_cdc_delete_certificate', 'cdc_delete_certificate');
function cdc_delete_certificate() {
    // Verify nonce and permissions
    if (!wp_verify_nonce($_POST['nonce'], 'cdc_nonce') || !current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
    }
    
    $filename = sanitize_file_name($_POST['filename']);
    $filepath = CDC_CERTIFICATE_DIR . $filename;
    
    if (file_exists($filepath) && unlink($filepath)) {
        wp_send_json_success('Certificate deleted');
    } else {
        wp_send_json_error('Failed to delete certificate');
    }
}

// Handle certificate download
add_action('wp_ajax_cdc_download_certificate', 'cdc_download_certificate');
add_action('wp_ajax_nopriv_cdc_download_certificate', 'cdc_download_certificate');
function cdc_download_certificate() {
    $cert_number = sanitize_file_name($_POST['cert_number']);
    
    // Check if certificate exists
    $extensions = array('pdf', 'jpeg', 'jpg', 'png');
    $file_path = '';
    
    foreach ($extensions as $ext) {
        $possible_file = CDC_CERTIFICATE_DIR . $cert_number . '.' . $ext;
        if (file_exists($possible_file)) {
            $file_path = $possible_file;
            break;
        }
    }
    
    if (empty($file_path)) {
        wp_send_json_error('Certificate not found');
    }
    
    $mime_type = mime_content_type($file_path);
    $file_name = basename($file_path);
    
    // Send file to browser
    header('Content-Description: File Transfer');
    header('Content-Type: ' . $mime_type);
    header('Content-Disposition: attachment; filename="' . $file_name . '"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file_path));
    
    readfile($file_path);
    exit;
}

// Certificate verification
add_action('wp_ajax_cdc_verify_certificate', 'cdc_verify_certificate');
add_action('wp_ajax_nopriv_cdc_verify_certificate', 'cdc_verify_certificate');
function cdc_verify_certificate() {
    $cert_number = sanitize_file_name($_POST['cert_number']);
    
    // Check if certificate exists
    $extensions = array('pdf', 'jpeg', 'jpg', 'png');
    $exists = false;
    $extension = '';
    
    foreach ($extensions as $ext) {
        $possible_file = CDC_CERTIFICATE_DIR . $cert_number . '.' . $ext;
        if (file_exists($possible_file)) {
            $exists = true;
            $extension = $ext;
            break;
        }
    }
    
    if ($exists) {
        wp_send_json_success(array('extension' => $extension));
    } else {
        wp_send_json_error('Certificate not found');
    }
}

// Serve certificate preview image
add_action('wp_ajax_cdc_serve_preview', 'cdc_serve_preview');
add_action('wp_ajax_nopriv_cdc_serve_preview', 'cdc_serve_preview');
function cdc_serve_preview() {
    $cert_number = sanitize_file_name($_GET['cert_number']);
    
    // Check if certificate exists
    $extensions = array('jpeg', 'jpg', 'png');
    $file_path = '';
    
    foreach ($extensions as $ext) {
        $possible_file = CDC_CERTIFICATE_DIR . $cert_number . '.' . $ext;
        if (file_exists($possible_file)) {
            $file_path = $possible_file;
            break;
        }
    }
    
    if (empty($file_path)) {
        wp_die('Certificate preview not available');
    }
    
    $mime_type = mime_content_type($file_path);
    
    // Serve image with appropriate headers
    header('Content-Type: ' . $mime_type);
    header('Content-Length: ' . filesize($file_path));
    readfile($file_path);
    exit;
}

// Shortcode for certificate download center
add_shortcode('certificate_download_center', 'cdc_shortcode');
function cdc_shortcode() {
    ob_start();
    include CDC_PLUGIN_PATH . 'templates/certificate-form.php';
    return ob_get_clean();
}